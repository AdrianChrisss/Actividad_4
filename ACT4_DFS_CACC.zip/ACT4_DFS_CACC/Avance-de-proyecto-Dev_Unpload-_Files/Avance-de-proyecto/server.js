// Definición de módulos/librerías
require('dotenv').config();
const cors = require('cors');
const express = require('express');
const mongoose = require('mongoose');

// Inicializar app
const app = express();

// Habilitar CORS para todas las peticiones
app.use(cors({
    origin: '*', // Permite todas las URL
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Procesamiento de peticiones JSON
app.use(express.json());

// Realiza la conexión con MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Conexión exitosa a MongoDB'))
    .catch((error) => console.error('Error al intentar conectarse:', error.message));

// Cargar las rutas correctamente
const rutaUser = require('./rutas/rutaUser'); 
app.use('/api', rutaUser); // Se corrige el prefijo de la ruta

// Iniciar servidor
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`El servidor se está ejecutando en el puerto ${PORT}`));
